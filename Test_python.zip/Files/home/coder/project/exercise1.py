# Program to illustrate Implicit type conversion
# creating addition() function to add two numbers
def addition(a, b):
    print("Type of first number(a) :", a, type(a))
    print("Type of second number(b) :", b, type(b))
    c = a + b
    print("Type of resulting variable(c) :",  c, type(c))
# addition() function calls with different inputs
addition(21, 23)   # both integers
print('\n')
addition(21, 23.0) # second being float
print('\n')
addition(21.0, 23) # first being float
print('\n')
addition(21.0, 23.0) # both float