# Program to illustrate Explicit type conversion
# creating addition() function to add two numbers
def addition(a, b):
    print("Type of first number(a) :", a, type(a))
    print("Type of second number(b) :", b, type(b))
    c = a + b
    print("Type of resulting variable(c) :", c, type(c))
print("accepting input from the user -->")
print("Enter first number")
num1 = input()
print("Enter second number")
num2 = input()
# addition() function call
addition(num1, num2)
print('\n')